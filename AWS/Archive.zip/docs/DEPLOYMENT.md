SuspiciousPi is built using gulp.

First, install dependencies

```sh
npm install
bower install
```

Then build and run!

```sh
gulp
```

Access the site locally through [http://localhost:5000](http://localhost:5000).