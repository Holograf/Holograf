# Suspicious Pi

Suspicious Pi is a tool for visualizing programs.

##Deployment

SuspiciousPi is built using gulp.

First, install dependencies

```sh
npm install
bower install
```

Then build and run

```sh
gulp
```
Access the site locally through [http://localhost:5000](http://localhost:5000).


## Contributing

See [CONTRIBUTING.md](docs/CONTRIBUTING.md) for contribution guidelines.

