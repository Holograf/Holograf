var keyMirror = require('keymirror');

module.exports = keyMirror({
  UPDATE_CODE: null,
  COMPILE: null,
  UPDATE_SHAREURL: null
});
