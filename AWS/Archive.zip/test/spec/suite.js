// Include all specs here, this should be dynamic
require("./component/parser.spec");
require("./component/program.spec");