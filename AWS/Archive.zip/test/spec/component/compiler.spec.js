var React = require("react/addons");
// var networkData = require("../../../app/common/data");
// var TubeTracker = require("../../../app/component/tube-tracker.jsx");

// var stubComponent = require("../../lib/stub/component");
// var stubPrediction = require("../../lib/stub/prediction");

describe("Compiler", function() {

  it("should run a test", function() {
    expect(1).toBe(1);
  });

});
